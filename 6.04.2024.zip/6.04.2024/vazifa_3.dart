import 'dart:io';

void main(List<String> args) {
  List maze = [
    [1, 3, 1, 1, 1, 1, 1],
    [1, 0, 0, 0, 0, 0, 1],
    [1, 0, 1, 0, 1, 0, 1],
    [0, 2, 1, 0, 0, 0, 1],
    [1, 0, 1, 0, 1, 0, 1],
    [1, 0, 0, 0, 0, 0, 1],
    [1, 1, 1, 0, 1, 0, 1]
  ];
  stdout.write('\x1B[2J\x1B[0;0H');
  print("\n                  --> MAZE O'YINIGA HUSH KELIBSIZ <--\n\n");

  print("""Qo'llanma:
    0 = Yurish mumkin bo'lgan yo'lak
    1 = Devor
    2 = O'yinchi
    3 = Finish chizig'i\n\n""");
  print("BUYRUQLARNI KIRITISH QUYDAGICHA_(o'nga, chapga, tepaga, pastga, exit)\n");

  while (true) {
    Game.labyrinth(maze);
  }
}




// CLASS GAME
class Game {

    // METHOD LABYRINTH
  static labyrinth(List maze) {

    // PRINT TABLE LABYRINTH
    print(
        "${maze[0]}\n${maze[1]}\n${maze[2]}\n${maze[3]}\n${maze[4]}\n${maze[5]}\n${maze[6]}\n");
    stdout.write("BUYRUQ KIRITING...   :->  ");
    String? command = stdin.readLineSync()!;
    // SWITCH CASE SECTION 
    switch (command) {
        // COMMAND RIGHT
      case "o'nga":
       stdout.write('\x1B[2J\x1B[0;0H');
        for (int i = 0; i < maze.length; i++) {
          for (var j = 0; j < maze[i].length; j++) {
            if (maze[i][j] == 2) {
              if (j != 6) {
                if (maze[i][j + 1] == 1) {
                  print("\n...DEVOR...\n\n");
                  break;
                }

                // GAME OVER
                if (maze[i][j+1] == 3) {
                  stdout.write('\x1B[2J\x1B[0;0H');
                  print("\nTABRIKLAYMAN SIZ G'OLIB BO'LDINGIZ <--");
                  return;
                } 

                // EXCHANGE
                if(maze[i][j+1] == 0) {
                  int box = maze[i][j];
                  maze[i][j] = maze[i][j + 1];
                  maze[i][j + 1] = box;
                }
              }
            //   BREAK TREET
              if (j == 6) {
                stdout.write('\x1B[2J\x1B[0;0H');
                print("\nO'NGA YO'L YO'Q !!!\n");
                break;
              }
              break;
            }
          }
        }
        break;
        // COMMAND LEFT
      case "chapga":
        stdout.write('\x1B[2J\x1B[0;0H');
        for (int i = 0; i < maze.length; i++) {
          for (var j = 0; j < maze[i].length; j++) {
            if (maze[i][j] == 2) {
              if (j != 0) {
                if (maze[i][j - 1] == 1) {
                  print("\n...DEVOR...\n\n");
                  break;
                }

                // GAME OVER
                if (maze[i][j-1] == 3) {
                  stdout.write('\x1B[2J\x1B[0;0H');
                  print("\nTABRIKLAYMAN SIZ G'OLIB BO'LDINGIZ <--");
                  return;
                } 

                // EXCHANGE
                if(maze[i][j-1] == 0) {
                  int box = maze[i][j];
                  maze[i][j] = maze[i][j - 1];
                  maze[i][j - 1] = box;
                }
              }

            //   BREAK STREET
              if (j == 0) {
                stdout.write('\x1B[2J\x1B[0;0H');
                print("\nCHAPGA YO'L YO'Q !!!\n");
                break;
              }
              break;
            }
          }
        }
        break;
      case "tepaga":
    //   COMMAND HIGH
        stdout.write('\x1B[2J\x1B[0;0H');
        for (int i = 0; i < maze.length; i++) {
          for (var j = 0; j < maze[i].length; j++) {
            if (maze[i][j] == 2) {

                // BREAK STREET
              if (i != 0) {
                if (maze[i - 1][j] == 1) {
                  print("\n...DEVOR...\n\n");
                  break;
                }

                // GAME OVER
                if (maze[i - 1][j] == 3) {
                  stdout.write('\x1B[2J\x1B[0;0H');
                  print("\nTABRIKLAYMAN SIZ G'OLIB BO'LDINGIZ <--");
                  return;
                } 

                // EXCHANGE
                if(maze[i-1][j] == 0) {
                  int box = maze[i][j];
                  maze[i][j] = maze[i - 1][j];
                  maze[i - 1][j] = box;
                }
              }

            //   BREAK STREET
              if (i == 0) {
                stdout.write('\x1B[2J\x1B[0;0H');
                print("\nTEPAGA YO'L YO'Q !!!\n");
                break;
              }
              break;
            }
          }
        }
        break;
        // COMMAND LOW
      case "pastga":
        stdout.write('\x1B[2J\x1B[0;0H');
        for (int i = 0; i < maze.length; i++) {
          for (var j = 0; j < maze[i].length; j++) {
            if (maze[i][j] == 2) {
                // BREAK STREET
              if (i != 6) {
                if (maze[i + 1][j] == 1) {
                  print("\n...DEVOR...\n\n");
                  break;
                }

                // GAME OVER
                if (maze[i+1][j] == 3) {
                  stdout.write('\x1B[2J\x1B[0;0H');
                  print("\nTABRIKLAYMAN SIZ G'OLIB BO'LDINGIZ <--");
                  return;
                } 

                // EXCHANGE
                if(maze[i+1][j] == 0) {
                  int box = maze[i][j];
                  maze[i][j] = maze[i + 1][j];
                  maze[i + 1][j] = box;
                }
              }

            //   BREAK STREET
              if (i == 6) {
                stdout.write('\x1B[2J\x1B[0;0H');
                print("PASTGA YO'L YO'Q !!!\n");
                break;
              }
            }
          }
        }
        break;
        // EXIT PROGRAMM
      case "exit":
        print("BIZ BILAN VAHT O'TKAZGANINGIZ UCHUN TASHAKKU :)");
        exit(0);
      default:
    }
  }
}
